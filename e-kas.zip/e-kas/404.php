<h1>404 Not Found</h1>
<p>Halaman yang anda cari tidak ditemukan</p>
<a href="admin.php?page=dashboard">Kembali ke dashboard</a>