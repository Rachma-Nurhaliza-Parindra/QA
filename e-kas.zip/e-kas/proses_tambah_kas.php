<?php
session_start();
require 'connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_kelas = $_POST['id_kelas'];
    $nama = $_POST['nama'];
    $tanggal_pembayaran = $_POST['tanggal_pembayaran'];
    $keterangan = $_POST['keterangan'];

    // Insert data into kas table
    $query = "INSERT INTO kas (id_kelas, nama, tanggal_pembayaran, keterangan) VALUES ('$id_kelas', '$nama', '$tanggal_pembayaran', '$keterangan')";

    if (mysqli_query($conn, $query)) {
        // Redirect to kas.php after successful insertion
        header("Location: admin.php?page=kas");
        exit();
    } else {
        echo 'Gagal menambahkan data uang kas: ' . mysqli_error($conn);
        echo '<br><a href="admin.php?page=form_tambah_kas">Kembali</a>';
    }
}
?>