<?php
session_start();
require 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Sanitize inputs to prevent SQL injection
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // Query the user table
    $query = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
    $jumlah_record = mysqli_num_rows($query);

    if ($jumlah_record == 1) {
        $result = mysqli_fetch_array($query, MYSQLI_ASSOC);

        // Check if the result is not null before accessing its elements
        if ($result && password_verify($password, $result['password'])) {
            $_SESSION = [
                'id_user'      => $result['id_user'],
                'username'     => $result['username'],
                'level'        => $result['level'],
                'is_logged_in' => TRUE
            ];

            // Query the siswa table
            $data = mysqli_query($conn, "SELECT id_kelas FROM siswa WHERE id_user = '{$result['id_user']}'");
            $id_kelas = mysqli_fetch_array($data, MYSQLI_ASSOC);

            // Check if id_kelas is not null before assigning it to session
            if ($id_kelas) {
                $_SESSION['id_kelas'] = $id_kelas['id_kelas'];
            } else {
                $_SESSION['id_kelas'] = null; // or handle this case as needed
            }

            echo "Login Berhasil!<br> Silahkan masuk ke <a href='admin.php?page=dashboard'>Halaman Admin</a>";
        } else {
            echo 'Password tidak cocok';
        }
    } else {
        echo 'Username yang anda masukkan tidak terdaftar di website kami';
    }
} else {
    echo 'Invalid request method.';
}
?>
